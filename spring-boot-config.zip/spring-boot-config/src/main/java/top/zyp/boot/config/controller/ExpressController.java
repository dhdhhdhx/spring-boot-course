package top.zyp.boot.config.controller;

/**
 * @Author: calm_sunset
 * @Date: 2025/9/12
 * @Version: 1.0
 */


public class ExpressController {
}
