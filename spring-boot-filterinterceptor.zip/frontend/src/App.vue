<template>
  <Login/>
</template>

<script lang="ts" setup>
import Login from "./components/Login.vue";
</script>

